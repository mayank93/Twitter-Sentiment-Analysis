db = DAL("sqlite://storage.sqlite")

from gluon.tools import Auth
auth = Auth(db)
auth.define_tables()

db.define_table('admin',
  Field('name','string',length=70,requires=IS_NOT_EMPTY()),
  Field('email', unique=True),
 )

db.define_table('contact',
  Field('address','text',length=70,requires=IS_NOT_EMPTY()),
  Field('email', unique=True),
  Field('phoneNo',requires=IS_NOT_EMPTY()),
 )

db.define_table('team',
  Field('name','string',length=70,requires=IS_NOT_EMPTY()),
  Field('email', unique=True),
  Field('designation',requires=IS_IN_SET(['Professor','Associate Professor','Assistant Professor','Visiting/Adjunct Faculty','Lecturer','PhD','PhD (External)','MS by Research','B.Tech',])),
  Field('interest','text',length=200),
  Field('phone','integer'),
  Field('website','string'),
  Field('image', 'upload'),
 )

db.define_table('project',
  Field('title','string',length=150,requires=IS_NOT_EMPTY(),unique=True),
  Field('head','string',length=150,requires=IS_NOT_EMPTY()),
  Field('email',requires=IS_NOT_EMPTY()),
  Field('keywords','string',length=250,requires=IS_NOT_EMPTY()),
  Field('details','text'),
  Field('link','string'),
  Field('image', 'upload'),
  Field('tim','datetime',default=request.now,writable=False,readable=False),
 )

db.define_table('projectteam',
  Field('title','string',length=100,requires=IS_NOT_EMPTY()),
  Field('email', required=True),
  Field('member', 'string',length=200,requires=IS_NOT_EMPTY()),
  Field('tim','datetime',default=request.now,writable=False,readable=False),
 )

db.define_table('event',
  Field('title','string',length=100,requires=IS_NOT_EMPTY(),unique=True),
  Field('date','date',requires=IS_NOT_EMPTY()),
  Field('location','string',length=350),
  Field('details','text'),
  Field('image', 'upload'),
  Field('tim','datetime',default=request.now,writable=False,readable=False),
 )

db.define_table('service',
  Field('name','string',length=100,requires=IS_NOT_EMPTY()),
  Field('emaili'),
  Field('organisation','string',requires=IS_NOT_EMPTY()),
  Field('role','string',length=150),
  Field('year', 'string'),
  Field('tim','datetime',default=request.now,writable=False,readable=False),
 )

db.define_table('course',
  Field('name','string',requires=IS_NOT_EMPTY()),
  Field('emailid'),
  Field('details','text'),
  Field('instructor','string',length=70),
  Field('website','string'),
 )

db.define_table('publication',
  Field('title','string',requires=IS_NOT_EMPTY(),unique=True),
  Field('project','string'),
  Field('type1',requires=IS_IN_SET(['Book','Case Study','Conference','Consortium','Doctoral','Journal','Note','Poster','Workshop'])),
  Field('area','string'),
  Field('year', 'string'),
  Field('name'),
  Field('url','string'),
  Field('tim','datetime',default=request.now,writable=False,readable=False),
 )

db.define_table('publication_author',
  Field('title1','string'),
  Field('name'),
  Field('idd')
 )
