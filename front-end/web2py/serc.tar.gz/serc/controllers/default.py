import datetime
import smtplib
import re
# Import the email modules we'll need
from email.mime.text import MIMEText

CAS.login_url='https://login.iiit.ac.in/cas/login'
CAS.check_url='https://login.iiit.ac.in/cas/validate'
CAS.logout_url='https://login.iiit.ac.in/cas/logout'
CAS.my_url='http://127.0.0.1:8000/serc/default/login'


def download(): return response.download(request,db)


def login():
    session.pdf1=0
    session.login =0
    session.token = CAS.login(request)
    addteam()
    return dict()

def logout():
    session.token=None
    CAS.logout()
#########################################################################

def index():
    """
    example action using the internationalization operator T and flash
    rendered by views/default/index.html or views/generic.html

    if you need a simple wiki simple replace the two lines below with:
    return auth.wiki()
    """
    home()
    return dict(message=T('Hello World'))

def calendar():
    return dict()

def home():
    project=db().select(db.project.ALL)
    event1=db().select(db.event.ALL,orderby=db.event.date)
    event=db().select(db.event.ALL,orderby=~db.event.date)
    date=datetime.date.today()
    return dict(project=project,event=event,date=date,event1=event1)
##########################################################################Admin
def admin():
    c=0;
    email=[]
    name=[]
    em=""
    tog=0;
    count=0
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    team=db().select(db.team.ALL,orderby=db.team.name)    
    for teams in team:
        email.append(teams.email)
        name.append(teams.name)
        count=count+1;
    db.admin.name.requires=IS_IN_SET(name)
    db.admin.email.default='None';
    db.admin.email.readable=False;
    db.admin.email.writable=False;
    form = SQLFORM(db.admin, labels = {'name':'Name','email':'Email-Id*'})
    admin=db().select(db.admin.ALL,orderby=db.admin.name)
    if form.process().accepted:
        for row in db(db.team.name==request.vars.name).select():
            em=row.email
        db(db.admin.name==request.vars.name).update(email=em)  
        session.flash = 'Admin added'
        redirect('admin.html')
    elif form.errors:
        tog=1
        response.flash = 'form has errors'
    return dict(form=form,admin=admin,tog=tog)
    
def deleteadmin():
    db(db.admin.id==request.args[0]).delete()
    session.flash = 'Admin deleted'
    redirect('../admin.html')
######################################################################## TEAM

def addteam():
    c=0;tog=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'Not An Authorized Member'
        redirect('home.html') 
    form = SQLFORM(db.team, labels = {'name':'Name','email':'Email-Id*','designation':'Designation*','interest':'Research Interests (Max 200 characters and Each interest seperated by comas)','phone':'Phone No','website':'Website','image':'Upload Image'})
    team=db().select(db.team.ALL,orderby=db.team.name)
    fromaddr = "From: " +session.token
    mail_header="SERC Membership"
    if form.process().accepted:
        server = smtplib.SMTP('mail.iiit.ac.in')
        server.set_debuglevel(1)  
        toaddrs = request.vars.email
        msg="You have been added as SERC member"
        headers = [ fromaddr,
        "to: " + toaddrs,
        "subject: " + mail_header,
        "content_type: text/html"]
        headers = "\r\n".join(headers)
        server.sendmail(fromaddr, toaddrs, headers + "\r\n\r\n" + msg + "\n\n"+ "Regards" +"\n" + session.token)
        server.quit()
        session.flash = 'Team member added'
        redirect('addteam.html')
    elif form.errors:
        tog=1
        response.flash = 'form has errors'
    return dict(form=form,team=team,tog=tog)

def updateteam():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    query=(db.team.id==request.args[0])
    set=db(query)
    prof=set.select()
    studentid=prof[0].id
    form=SQLFORM(db.team,studentid,fields=['name','email','designation','interest','phone','website','image'])
    if form.accepts(request.vars,session):
          session.flash="Information Updated"
          redirect('../addteam.html')
    return dict(form=form)


def addinfo():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    if 'add' in request.post_vars.keys():
         if 'idd' in request.post_vars.keys():
            session.my=request.post_vars['idd']
    for row in db(db.team.id==session.my).select():
        name=row.name
        email=row.email
        website=row.website
    db.project.head.default=name;
    db.project.email.default=email;
    db.project.head.writable=False;
    db.project.email.writable=False;
    ######
    db.service.name.default=name;
    db.service.email.default=email;
    db.service.name.writable=False;
    db.service.email.writable=False;
    #######
    db.course.instructor.default=name;
    db.course.emailid.default=email;
    db.course.website.default=website;
    db.course.instructor.writable=False;
    db.course.emailid.writable=False;
    db.course.website.writable=False;
    
    form1 = SQLFORM(db.project, labels = {'title':'Title Of Project','head':'Incharge','email':'Email ID of Incharge','keywords':'Brief Description (Max 80)','details':'Complete Description','link':'URL for Project','image':'Image',})
    if form1.accepts(request.vars,session):
          session.flash="Project added"
          redirect(URL(r=request,f='addinfo'))
    form2 = SQLFORM(db.service, labels = {'name':'Name Of the Person *','email':'Email ID *','organisation':'Name of Organisation *','role':'Role','year':'Year( years seperated by commas)',})
    if form2.accepts(request.vars,session):
          session.flash="Service Added"
          redirect(URL(r=request,f='addinfo'))
    form3 = SQLFORM(db.course, labels = {'name':'Name','emailid':'Email-Id*'},fields=['name'])
    if form3.accepts(request.vars,session):
          session.flash="Course Added"
          redirect(URL(r=request,f='addinfo'))
    return dict(form1=form1,form2=form2,form3=form3)

def deleteteam():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    db(db.team.id==request.args[0]).delete()
    session.flash = 'Team Member deleted'
    redirect('../addteam.html')

def team():
     team=db().select(db.team.ALL,orderby=db.team.name)
     return dict(team=team)

def teamdetail():
    for row in db(db.team.id==request.vars.suggest).select():
        name=row.name
        idd=row.id
        email=row.email
        designation=row.designation
        interest=row.interest
        phone=row.phone
        website=row.website
        image=row.image
    project=db().select(db.project.ALL,orderby=db.project.title)
    projectteam=db().select(db.projectteam.ALL)
    publication_author=db().select(db.publication_author.ALL)
    return dict(project=project,projectteam=projectteam,image=image,website=website,phone=phone,interest=interest,designation=designation,email=email,name=name,idd=idd,publication_author=publication_author)
############################################################################## project

def addproject():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    email=[]
    name=[]
    count=0;
    website=""
    em=""
    tog=0;
    team=db().select(db.team.ALL,orderby=db.team.email)
    for teams in team:
        email.append(teams.email)
        name.append(teams.name)
        count=count+1;
    db.project.head.requires=IS_IN_SET(name)
    db.project.email.default='None';
    db.project.email.readable=False;
    db.project.email.writable=False;
    project=db().select(db.project.ALL)
    form = SQLFORM(db.project, labels = {'title':'Title Of Project','head':'Incharge','email':'Email ID of Incharge','keywords':'Brief Description (Max 80)','details':'Complete Description','link':'URL for Project','image':'Image',})
    if form.accepts(request.vars,session):
        for row in db(db.team.name==request.vars.head).select():
            em=row.email
        db(db.project.title==request.vars.title).update(email=em)    
        session.flash="Project added"
        redirect('addproject.html')
    elif form.errors:
        tog=1
        response.flash = 'form has errors'
    return dict(form=form,project=project,tog=tog)

def deleteproject():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    db(db.project.id==request.args[0]).delete()
    session.flash = 'Project deleted'
    redirect('../addproject.html')

def updateproject():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    query=(db.project.id==request.args[0])
    set=db(query)
    prof=set.select()
    studentid=prof[0].id
    form=SQLFORM(db.project,studentid,fields=['title','head','email','keywords','details','link','image'])
    if form.accepts(request.vars,session):
          session.flash="Project Information Updated"
          redirect('../addproject.html')
    return dict(form=form)

def project():
    project=db().select(db.project.ALL,orderby=db.project.title)
    return dict(project=project)

def teamproject():
    if 'add' in request.post_vars.keys():
         if 'idd' in request.post_vars.keys():
            session.pro=request.post_vars['idd']
    for row in db(db.project.id==session.pro).select():
         title=row.title
         email=row.email
    db.projectteam.title.default=title;
    db.projectteam.email.default=email;
    db.projectteam.title.writable=False;
    db.projectteam.email.writable=False;
    form=SQLFORM(db.projectteam)
    projectteam = db(db.projectteam.title == title).select(db.projectteam.ALL)
    if form.accepts(request.vars,session):
          session.flash="Team Member Added"
          redirect(URL(r=request,f='teamproject'))
    return dict(form=form,projectteam=projectteam)   

def deleteprojectteam():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    db(db.projectteam.id==request.args[0]).delete()
    session.flash = 'Team Member deleted'
    redirect(URL(r=request,f='teamproject'))


def projectdetail():
    for row in db(db.project.id==request.vars.suggest).select():
        title=row.title
        idd=row.id
        head=row.head
        email=row.email
        keywords=row.keywords
        detail=row.details
        link=row.link
        image=row.image
    projectteam=db().select(db.projectteam.ALL)
    publication=db().select(db.publication.ALL)
    team=db().select(db.team.ALL)
    return dict(title=title,head=head,publication=publication,email=email,keywords=keywords,detail=detail,link=link,image=image,projectteam=projectteam,team=team,idd=idd)

#########################################################################################3333//////Events

def addevent():
    c=0;tog=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    event=db().select(db.event.ALL,orderby=~db.event.date)
    form = SQLFORM(db.event, labels = {'title':'Name Of the Event *','date':'Date *','location':'Location','details':'Description','image':'Image',})
    if form.accepts(request.vars,session):
          session.flash="Event Added"
          redirect('addevent.html')
    elif form.errors:
        tog=1
        response.flash = 'form has errors'         
    return dict(form=form,event=event,tog=tog)

def deleteevent():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    db(db.event.id==request.args[0]).delete()
    session.flash = 'Event deleted'
    redirect('../addevent.html')

def updateevent():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    query=(db.event.id==request.args[0])
    set=db(query)
    prof=set.select()
    studentid=prof[0].id
    form=SQLFORM(db.event,studentid,fields=['title','date','location','details','image'])
    if form.accepts(request.vars,session):
          session.flash="Event Information Updated"
          redirect('../addevent.html')
    return dict(form=form)

def event():
    
    event1=db().select(db.event.ALL,orderby=~db.event.date)#big to small
    event=db().select(db.event.ALL,orderby=db.event.tim)
    date=datetime.date.today()
    return dict(event=event,event1=event1,date=date)

def eventdetail():
    for row in db(db.event.id==request.vars.suggest).select():
        title=row.title
        idd=row.id
        date=row.date
        location=row.location
        detail=row.details
        image=row.image
    return dict(title=title,detail=detail,location=location,image=image,idd=idd,date=date)

############################################################################################333///////////service

def addservice():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    
    team=db().select(db.team.ALL,orderby=db.team.email)
    email=[]
    name=[]
    em=""
    idd=""
    tog=0;
    for teams in team:
        email.append(teams.email)
        name.append(teams.name)
    db.service.emaili.requires=IS_IN_SET(email)
    db.service.name.requires=IS_IN_SET(name)
    db.service.emaili.default='None';
    db.service.emaili.readable=False;
    db.service.emaili.writable=False; 
    service=db().select(db.service.ALL,orderby=~db.service.year)
    form = SQLFORM(db.service, labels = {'name':'Name Of the Person *','emaili':'Email ID *','organisation':'Name of Organisation *','role':'Role','year':'Year( years seperated by commas)',})
    if form.accepts(request.vars,session):
        service=db().select(db.service.ALL,orderby=~db.service.tim)
        for row in db(db.team.name==request.vars.name).select():
            em=row.email
        for services in service:
            if(services.name==request.vars.name):
               idd=services.id;
               break;
        db(db.service.id==idd).update(emaili=em) 
        session.flash="Service Added"
        redirect('addservice.html')
    elif form.errors:
        tog=1
        response.flash = 'form has errors'
        
    return dict(form=form,service=service,tog=tog)

def deleteservice():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    
    db(db.service.id==request.args[0]).delete()
    session.flash = 'Service deleted'
    redirect('../addservice.html')

def updateservice():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    query=(db.service.id==request.args[0])
    set=db(query)
    prof=set.select()
    studentid=prof[0].id
    form=SQLFORM(db.service,studentid,fields=['name','emaili','organisation','role','year'])
    if form.accepts(request.vars,session):
          session.flash="Service Information Updated"
          redirect('../addservice.html')
    return dict(form=form)

def service():
    service=db().select(db.service.ALL,orderby=~db.service.year)
    return dict(service=service)

###################################################################################################///////////courses

def addcourses():
    c=0;tog=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    course=db().select(db.course.ALL)
    email=[]
    count=0;
    website=""
    details=""
    name="";tog=0;
    team=db().select(db.team.ALL,orderby=db.team.email)
    for teams in team:
        email.append(teams.email)
        count=count+1;
    if 'add' in request.post_vars.keys():
         if 'name' in request.post_vars.keys():
            name=request.post_vars['name']
         if name =="":
             tog=1
             response.flash="Add the Name Of the Course"
         else:    
            if 'emailid' in request.post_vars.keys():
                emailid=request.post_vars['emailid']
            if 'details' in request.post_vars.keys():
                detail=request.post_vars['details']    
            emailidd=emailid
            instructor=emailidd.split('@');
            for row in db(db.team.email==emailid).select():
                instructor=row.name
                website=row.website
            db.course.insert(name=name,emailid=emailid,instructor=instructor,website=website,details=details)
            session.flash = 'Course Added'
            redirect('addcourses.html')
    return dict(course=course,email=email,count=count,tog=tog)

def deletecourse():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    db(db.course.id==request.args[0]).delete()
    session.flash = 'Course deleted'
    redirect('../addcourses.html')

def updatecourse():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    query=(db.course.id==request.args[0])
    set=db(query)
    prof=set.select()
    studentid=prof[0].id
    form=SQLFORM(db.course,studentid,fields=['name','emailid','instructor','website'])
    if form.accepts(request.vars,session):
          session.flash="Course Information Updated"
          redirect('../addcourses.html')
    return dict(form=form)

def course():
    course=db().select(db.course.ALL)
    return dict(course=course)

def coursedetail():
    for row in db(db.course.id==request.vars.suggest).select():
        name=row.name
        idd=row.id
        head=row.emailid
        instructor=row.instructor
        website=row.website
        detail=row.details
    return dict(name=name,head=head,instructor=instructor,website=website,detail=detail,idd=idd)

####################################################################################################.......publications
"""
def addpublication():
    c=0;
  #  if(db(db.admin.email==session.token).select()):
  
  #c=1;
   
   #if(c==0):
    #    session.flash = 'You Are Not An Authorized Member'
     #   redirect('home.html')
    publication=db().select(db.publication.ALL)
    email=[]
    pro=[]
    count=0;
    website=""
    count1=9
    count2=0;
    t=['Book','Case Study','Conference','Consortium','Doctoral','Journal','Note','Poster','Workshop'];
    team=db().select(db.team.ALL,orderby=db.team.email)
    project=db().select(db.project.ALL)
    for teams in team:
        email.append(teams.name)
        count=count+1;
    for projects in project:
        pro.append(projects.title)
        count2=count2+1
    pro.append("other")
    title="";type1="";name="";area="";year="";url="";idd="";project="None";
    if 'add' in request.post_vars.keys():
         if 'title' in request.post_vars.keys():
            title=request.post_vars['title']
         else:
            session.flash="Add a title"
            redirect('addpublication.html')
         if 'type' in request.post_vars.keys():
            type1=request.post_vars['type']
         if 'area' in request.post_vars.keys():
            area=request.post_vars['area']
         if 'year' in request.post_vars.keys():
            year=request.post_vars['year']
         if 'url' in request.post_vars.keys():
            url=request.post_vars['url']
         if 'name' in request.post_vars.keys():
            name=request.post_vars['name']
         if 'project' in request.post_vars.keys():
            project=request.post_vars['project']    
         p=name.split(',');
         num=len(p);
         db.publication.insert(title=title,type1=type1,area=area,year=year,name=name,url=url,project=project)
         for row in db(db.publication.title==title).select():
             idd=row.id
         for i in range(num):
             for row in db(db.team.name==p[i]).select():
                 db.publication_author.insert(title1=title,name=row.name,idd=idd)
         session.flash = 'Publication Added'
         redirect('addpublication.html')
    return dict(publication=publication,email=email,count=count,t=t,count1=count1,pro=pro,count2=count2)
"""

def addpublication():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
       session.flash = 'You Are Not An Authorized Member'
       redirect('home.html')
    publication=db().select(db.publication.ALL)
    email=[]
    pro=[]
    count=0;
    website=""
    count1=9;
    count2=0;tog=0;
    t=['Book','Case Study','Conference','Consortium','Doctoral','Journal','Note','Poster','Workshop'];
    team=db().select(db.team.ALL,orderby=db.team.name)
    project=db().select(db.project.ALL)
    email.append("");
    for teams in team:
        email.append(teams.name)
        count=count+1;
    for projects in project:
        pro.append(projects.title)
        count2=count2+1
    pro.append("other");
    title="";type1="";name="";area="";year="";url="";idd="";project="None";
    author1="";author2="";author3="";author4="";
    if 'add' in request.post_vars.keys():
         if 'title' in request.post_vars.keys():
            title=request.post_vars['title']
         if(title==""):
            tog=1; 
            response.flash="Add a title"
         else:
            if 'type' in request.post_vars.keys():
                type1=request.post_vars['type']
            if 'area' in request.post_vars.keys():
                area=request.post_vars['area']
            if 'year' in request.post_vars.keys():
                year=request.post_vars['year']
            if 'url' in request.post_vars.keys():
                url=request.post_vars['url']
            if 'author1' in request.post_vars.keys():
                author1=request.post_vars['author1']
            if 'author2' in request.post_vars.keys():
                author2=request.post_vars['author2']
            if 'author3' in request.post_vars.keys():
                author3=request.post_vars['author3']
            if 'author4' in request.post_vars.keys():
                author4=request.post_vars['author4']
            if 'project' in request.post_vars.keys():
                project=request.post_vars['project']    
            if(author1!=""):
                name=name+author1;
            if(author2!=""):
                name=name+", ";
                name=name+ author2;
            if(author3!=""):
                name=name+", ";
                name=name+ author3;
            if(author4!=""):
                name=name+", ";
                name=name+ author4;
            db.publication.insert(title=title,type1=type1,area=area,year=year,name=name,url=url,project=project)   
            for row in db(db.publication.title==title).select():
                idd=row.id
            if(author1!=""):
                print author1;
                db.publication_author.insert(title1=title,name=author1,idd=idd)
            if(author2!=""):
                print author2;
                db.publication_author.insert(title1=title,name=author2,idd=idd)
            if(author3!=""):
                print author3;
                db.publication_author.insert(title1=title,name=author3,idd=idd)
            if(author4!=""):
                db.publication_author.insert(title1=title,name=author4,idd=idd)
            session.flash = 'Publication Added'
            redirect('addpublication.html')
    return dict(publication=publication,email=email,count=count,t=t,count1=count1,pro=pro,count2=count2,tog=tog)


def deletepublication():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    db(db.publication.id==request.args[0]).delete()
    db(db.publication_author.idd==request.args[0]).delete()
    session.flash = 'Publication deleted'
    redirect('../addpublication.html')

def updatepublication():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    query=(db.publication.id==request.args[0])
    set=db(query)
    prof=set.select()
    studentid=prof[0].id
    form=SQLFORM(db.publication,studentid,fields=['title','project','type1','area','year','name','url'])
    if form.accepts(request.vars,session):
          session.flash="Publication Information Updated"
          redirect('../addpublication.html')
    return dict(form=form)

def publication():
    publication=db().select(db.publication.ALL,orderby=~db.publication.year)
    return dict(publication=publication)

######################################################################################################contact Details

def addcontact():
    c=0;
    contact=db().select(db.contact.ALL)
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')    
    return dict(contact=contact)

def updatecontact():
    c=0;
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')
    query=(db.event.id==request.args[0])
    set=db(query)
    prof=set.select()
    studentid=prof[0].id
    form=SQLFORM(db.contact,studentid,fields=['address','email','phoneNo'])
    if form.accepts(request.vars,session):
          session.flash="Contact Information Updated"
          redirect('../addcontact.html')
    return dict(form=form)

def contact():
    c=0;
    contact=db().select(db.contact.ALL)
    if(db(db.admin.email==session.token).select()):
        c=1;
    if(c==0):
        session.flash = 'You Are Not An Authorized Member'
        redirect('home.html')    
    return dict(contact=contact)

##########################################################################################333
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request,db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()


@auth.requires_signature()
def data():
    """
    http://..../[app]/default/data/tables
    http://..../[app]/default/data/create/[table]
    http://..../[app]/default/data/read/[table]/[id]
    http://..../[app]/default/data/update/[table]/[id]
    http://..../[app]/default/data/delete/[table]/[id]
    http://..../[app]/default/data/select/[table]
    http://..../[app]/default/data/search/[table]
    but URLs must be signed, i.e. linked with
      A('table',_href=URL('data/tables',user_signature=True))
    or with the signed load operator
      LOAD('default','data.load',args='tables',ajax=True,user_signature=True)
    """
    return dict(form=crud())
